__version__ = '0.0.10'

"""
Version 0.0.10
- fixed the problem with the mv command
- if there is no match the programm ask for an alternative name instead of giving an error
"""