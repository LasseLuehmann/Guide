__version__ = '0.0.9'

"""
Version 0.0.9
- improved Docstrings in operation.py
- compressed and seperated utilityes of dartabase related fuctions
- add 'mv' command
- add 'mv -t' command
"""